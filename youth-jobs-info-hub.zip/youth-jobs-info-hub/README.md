# Youth Jobs Info Hub

A simple, low-cost website that collects free job, learnership and bursary resources for young South Africans, hosted on AWS.

**Live site:** `http://YOUR-BUCKET-NAME.s3-website-YOUR-REGION.amazonaws.com` *(replace with your S3 website endpoint)*

Built by **[YOUR NAME]** as my AWS re/Start project.

---

## The Problem

Youth unemployment is one of South Africa's biggest socio-economic problems. According to Stats SA's Quarterly Labour Force Survey for the second quarter of 2026 (released 11 August 2026), the official unemployment rate was **33.6%**, and the unemployment rate for people aged 15 to 34 was **47.4%**. About **5.0 million young people** were unemployed.

Many young people do not know where to find free opportunities, or cannot afford the data to search across many websites. Others fall for scams that charge fees for fake jobs or learnerships.

*Source: Statistics South Africa, Quarterly Labour Force Survey, Q2 2026 (https://www.statssa.gov.za).*

## The Solution

One small, fast web page that lists trusted, free resources in one place:

- Job and work-experience platforms (SA Youth, YES, Harambee, ESSA)
- Learnership and skills programme information (SETAs)
- Study funding (NSFAS, bursary listings)
- Youth support agencies (NYDA)
- A "before you apply" checklist and a warning about job scams

The page uses no images, no JavaScript and no external fonts, so it loads quickly on a cheap phone and uses very little data.

## Architecture

```
User's phone or laptop
        |
        v
  Amazon S3 static website  <---- IAM user (limited to this bucket only)
  (index.html)
        |
  CloudWatch billing alarm (cost protection)
```

## AWS Services Used and Why

| Service | What I used it for | Why I chose it |
|---|---|---|
| **Amazon S3** | Hosts `index.html` as a static website | Very cheap, no servers to manage, and always available. A good fit for a non-profit style project. |
| **IAM** | A separate user with a policy limited to this one bucket | Follows the principle of least privilege, so I do not use the root account for daily work. |
| **S3 bucket policy** | Allows the public to read files, but not change them | Visitors can view the site but cannot edit or delete anything. |
| **CloudWatch** | A billing alarm | Alerts me by email if costs go above my limit. |

## How I Built It

1. **Created the GitHub repo** and added `index.html` and this README.
2. **Created an IAM user** (not root) and attached the policy in [`iam-policy.json`](iam-policy.json), with my bucket name filled in.
3. **Created an S3 bucket** with a globally unique name.
4. **Turned off "Block all public access"** for this bucket only, because the website must be publicly readable.
5. **Added the bucket policy** from [`bucket-policy.json`](bucket-policy.json). It only allows `s3:GetObject`, which means read-only.
6. **Uploaded `index.html`** to the bucket.
7. **Enabled static website hosting** in the bucket's Properties tab and set the index document to `index.html`.
8. **Opened the website endpoint** in a browser to confirm the site works.
9. **Created a CloudWatch billing alarm** that emails me if estimated charges pass a small threshold. Billing alerts must be enabled in the account's Billing preferences first, and billing metrics appear in the US East (N. Virginia) region.

### Screenshots

Add one screenshot per step in the `screenshots/` folder and link them here.

| Step | Screenshot |
|---|---|
| IAM user and policy | `screenshots/01-iam-user.png` |
| S3 bucket created | `screenshots/02-s3-bucket.png` |
| Bucket policy | `screenshots/03-bucket-policy.png` |
| Static website hosting enabled | `screenshots/04-static-hosting.png` |
| Website working in browser | `screenshots/05-website-live.png` |
| CloudWatch billing alarm | `screenshots/06-billing-alarm.png` |

## Security Notes

- No access keys or passwords are stored in this repo.
- The bucket policy grants read-only public access to objects, and nothing else.
- The IAM user can only manage this one bucket.
- The root account is not used for daily tasks.

## Cost

Expected cost is close to zero. A single small HTML page on S3 is covered by typical free-tier limits, and the billing alarm warns me if that changes.

## What I Learned

*(Write 3 to 5 honest sentences in your own words. For example: what was new, what went wrong, and how you fixed it. A common one is the "Access Denied" error that appears if Block Public Access is still on, or if the bucket policy has the wrong bucket name.)*

## Future Improvements

- Add **Amazon CloudFront** and a certificate so the site is served over HTTPS and loads faster
- Add a custom `error.html` page
- Translate the page into isiZulu, isiXhosa, Afrikaans and Sesotho
- Add a province filter and more local resources
- Define the setup in **CloudFormation** so it can be recreated in one step

## Disclaimer

This is a learning project and not an official government website. Always confirm details on each organisation's own website.
